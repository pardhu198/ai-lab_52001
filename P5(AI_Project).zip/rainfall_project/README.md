# 🌧️ Rainfall Prediction Web App

A simple Flask web application that predicts **whether it will rain
tomorrow** based on weather parameters such as temperature, location,
wind speed, and rainfall status.\
The model is powered by a **Random Forest Classifier** trained on a
dataset (`rain_forecasting.csv`).

## 📌 Project Overview

This project uses machine learning to predict rainfall using weather
features.\
Users enter weather details in a web form, and the backend ML model
instantly outputs:\
➡️ **Yes** --- It will rain tomorrow\
➡️ **No** --- It will not rain tomorrow

## 🛠️ Tech Stack

### Backend

-   Python
-   Flask
-   pandas
-   scikit-learn

### Machine Learning

-   RandomForestClassifier\
-   Label Encoding for categorical variables

### Frontend

-   HTML (index.html template)

## 📂 Project Structure

    project-folder/
    │── app.py
    │── rain_forecasting.csv
    │── templates/
    │     └── index.html
    │── README.md

## 📄 Features

✔ Loads weather dataset\
✔ Encodes categorical columns (`Location`, `RainToday`, `RainTomorrow`)\
✔ Uses 5 features for prediction\
✔ Trained using Random Forest\
✔ Web form for user inputs\
✔ Displays prediction

## ⚙️ How It Works

1.  Dataset is loaded\
2.  Categorical columns encoded\
3.  Model trained\
4.  User inputs processed\
5.  Prediction displayed

## 🚀 How To Run

    pip install flask pandas scikit-learn
    python app.py

## 🧪 Model Details

-   Algorithm: RandomForestClassifier\
-   Trees: 100\
-   Features: Location, MinTemp, MaxTemp, RainToday, WindSpeed3pm

## 📝 Output

Will it rain tomorrow? Yes/No
