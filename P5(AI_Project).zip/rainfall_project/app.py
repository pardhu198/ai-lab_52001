from flask import Flask, request, render_template
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

# Initialize Flask app
app = Flask(__name__)

# Load dataset
df = pd.read_csv("rain_forecasting.csv")  # CSV file must match this name

# Encode categorical columns
label_cols = ['Location', 'RainToday', 'RainTomorrow']
label_encoders = {}
for col in label_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col].astype(str))
    label_encoders[col] = le

# Define features and target (only using 5 features now)
X = df[['Location', 'MinTemp', 'MaxTemp', 'RainToday', 'WindSpeed3pm']]
y = df['RainTomorrow']

# Train/test split and model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Home page
@app.route('/')
def home():
    return render_template('index.html')

# Prediction route
@app.route('/predict', methods=['POST'])
def predict():
    data = request.form

    # Create DataFrame from form
    input_df = pd.DataFrame([{
        'Location': data['Location'].title(),  # ensures capitalization
        'MinTemp': float(data['MinTemp']),
        'MaxTemp': float(data['MaxTemp']),
        'RainToday': data['RainToday'].capitalize(),  # Yes/No
        'WindSpeed3pm': float(data['WindSpeed3pm'])
    }])

    # Encode categorical columns
    for col in ['Location', 'RainToday']:
        le = label_encoders[col]
        input_df[col] = le.transform(input_df[col])

    # Predict
    prediction = model.predict(input_df)[0]
    result = 'Yes' if prediction == 1 else 'No'

    return render_template('index.html', prediction_text=f'Will it rain tomorrow? {result}')

# Run app
if __name__ == "__main__":
    app.run(debug=True)
